package com.hcl.sample;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.annotations.Test;

class Demo2 {

	@Test
	public void login() throws InterruptedException {

		WebDriver driver = null;

		System.setProperty("webdriver.edge.driver", "./drivers/msedgedriver.exe");
		EdgeOptions edgeOption = new EdgeOptions();
		edgeOption.addArguments(
				"user-data-dir=" + "C:\\Users\\gupta.ami\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default");
		edgeOption.addArguments("--start-maximized");

		driver = new EdgeDriver(edgeOption);
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.get("https://staging.myhcl.com/SR_New/");
		driver.findElement(By.xpath("//input[@id='EmployeeCode']")).sendKeys("40170924");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("123", Keys.ENTER);
		driver.findElement(By.xpath("//input[@id='SubmitButton']")).click();
		Thread.sleep(5000);
	}
}
