package com.hcl.smartrecruit.init;

import org.openqa.selenium.WebDriver;

import com.hcl.smartrecruit.pages.InitiatorHomePage;
import com.hcl.smartrecruit.pages.LoginPage;
import com.hcl.smartrecruit.util.WebActionUtil;

public class InitilizePages {

	 public LoginPage loginPage;
	 public InitiatorHomePage initiatorHomePage;
	 
	 
	public InitilizePages(WebDriver driver, long ETO,WebActionUtil WebActionUtil) {
		loginPage = new LoginPage(driver,ETO,WebActionUtil);
		initiatorHomePage = new InitiatorHomePage();
		
	}
}
