package com.hcl.smartrecruit.library;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import com.hcl.smartrecruit.util.WebActionUtil;

public class BaseTest {

	public WebDriver driver;
	public static Properties prop;
	public long ETO = 10, ITO = 10;
	public WebActionUtil WebActionUtil;

	@BeforeClass
	public void launchApp() throws IOException {
		try {
			prop = new Properties();
			FileInputStream fis = new FileInputStream(GenericLib.configPath);
			prop.load(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		String browser = prop.getProperty("Browser_edge");
		System.setProperty("webdriver.edge.driver", "./drivers/msedgedriver.exe");
		EdgeOptions edgeOption = new EdgeOptions();
		edgeOption.addArguments(
				"user-data-dir=" + "C:\\Users\\gupta.ami\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default");
		edgeOption.addArguments("--start-maximized");

		driver = new EdgeDriver(edgeOption);
	
//	
//			if (browser.equalsIgnoreCase("edge")) {
//				EdgeOptions edgeOption = new EdgeOptions();
//				edgeOption.addArguments(
//						"user-data-dir=" + "C:\\Users\\gupta.ami\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default");
//				edgeOption.addArguments("--start-maximized");
//
//				driver = new EdgeDriver(edgeOption);
//			} else if (browser.equalsIgnoreCase("chrome")) {
//				driver = new ChromeDriver();
//			}

			driver.manage().timeouts().implicitlyWait(ITO, TimeUnit.SECONDS);
			WebActionUtil = new WebActionUtil(driver, ETO);

		}

	

	@AfterClass
	public void closeApp() {
		
		try {
			if(driver != null) {
				driver.close();
				}
			else 
			{
				System.out.println("driver instance is null ");
			}
} catch(Exception e){
				e.printStackTrace();
			}
		
		}
		

	@BeforeMethod
	public void signToApp() {
		driver.get(prop.getProperty("App_URL"));
		driver.manage().window().maximize();
		

		
	}

}


