package com.hcl.smartrecruit.library;

public class GenericLib {
	
	public static String sDirPath = System.getProperty("user.dir");
	public static String configPath = "C:\\Users\\gupta.ami\\eclipse-workspace\\HCL_POC_PlainJava\\Config\\config.properties";

}
