package com.hcl.smartrecruit.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InitiatorHomePage {

	// Element to identify the initiator actions mouse over
	@FindBy(xpath = "//a[contains(text(),'Initiator Actions')]")
	private WebElement initiatorActionsDropdown;

	// Element to identify the create new requisition button
	@FindBy(xpath = "//a[contains(text(),'Create New Requisition')]")
	private WebElement createNewRequisitionBtn;

	// requestID = "BTIS/BTIS/2020/3064915"; 
	// request id should be fetch from the request confirmation pop up.
	// Element to identify the Initiator/Approver link for the newly created request
//	@FindBy(xpath = "//a[text()='" +requestID+ "']/../following-sibling::td[6]//a[.='Initiator/Approver']")
	private WebElement approverLnk;

	// Element to identify the pending with role pup up title
	@FindBy(xpath = "//strong[contains(text(),'Pending with role')]")
	private WebElement pendingRolePopupTitle;

	// Element to identify approver txt in the popup
	@FindBy(xpath = "//td[@style='text-align:left']")
	private WebElement approverName;

	// Element to identify close button at approver popup
	@FindBy(xpath = "//div[@class='modal-dialog roundCorners']//button[@class='btn-primary btn-sm'][contains(text(),'Close')]")
	private WebElement closeBtn;




}
