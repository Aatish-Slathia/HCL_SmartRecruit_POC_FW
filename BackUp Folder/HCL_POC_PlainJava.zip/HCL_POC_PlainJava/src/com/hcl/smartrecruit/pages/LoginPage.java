package com.hcl.smartrecruit.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcl.smartrecruit.library.BasePage;
import com.hcl.smartrecruit.util.WebActionUtil;

public class LoginPage extends BasePage {

	public LoginPage(WebDriver driver, long ETO, WebActionUtil WebActionUtil) {
		super(driver, ETO, WebActionUtil);
	}

	// Element to identify employee ID text field
	@FindBy(xpath = "//input[@id='EmployeeCode']")
	private WebElement employeeID;

	// Element to identify the password text field
	@FindBy(xpath = "//input[@id='Password']")
	private WebElement password;

	// Element to identify the login button
	@FindBy(xpath = "//input[@id='SubmitButton']")
	private WebElement loginBtn;

	public void signToApplication() throws InterruptedException, AWTException {
		WebActionUtil.typeText(employeeID, " 40170924", "Entering the EmployeeID");
		WebActionUtil.typeText(password, "123", "Entering the Password");
		
		
//		WebActionUtil.switchToTab(0);
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);

		WebActionUtil.clickOnElement(loginBtn, "Clicking on the Login Button");
		Thread.sleep(3000);
	}

}
