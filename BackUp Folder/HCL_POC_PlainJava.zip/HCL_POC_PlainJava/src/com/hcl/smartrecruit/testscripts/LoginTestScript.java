package com.hcl.smartrecruit.testscripts;

import java.awt.AWTException;

import org.testng.annotations.Test;

import com.hcl.smartrecruit.init.InitilizePages;
import com.hcl.smartrecruit.library.BaseTest;

public class LoginTestScript  extends BaseTest{

	@Test
	public void HCL_LoginTest() throws InterruptedException, AWTException {
		InitilizePages pages = new InitilizePages(driver, ETO, WebActionUtil);
		pages.loginPage.signToApplication();
	}
}
