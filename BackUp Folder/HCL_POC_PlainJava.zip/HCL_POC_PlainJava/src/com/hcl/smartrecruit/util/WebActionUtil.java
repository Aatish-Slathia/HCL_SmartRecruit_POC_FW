package com.hcl.smartrecruit.util;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.lang.reflect.Array;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import graphql.Assert;

public class WebActionUtil {

	public WebDriver driver;
	WebDriverWait wait;
	public long ETO = 10;

	public WebActionUtil(WebDriver driver, long ETO) {
		this.driver = driver;
		this.ETO = ETO;
		wait = new WebDriverWait(driver, ETO);
	}

	/**
	 * @author Aatish Slathia
	 * @param element elementName
	 * @return
	 */
	public boolean isElementClickable(WebElement element, String elemantName) {

		try {
			wait.until(ExpectedConditions.visibilityOf(element));
			wait.until(ExpectedConditions.elementToBeClickable(element));
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	
	public void clickOnElement(WebElement element, String elementName) {
		if(isElementClickable(element, elementName)){
			element.click();
		}else {
			Assert.assertTrue(wait.until(ExpectedConditions.visibilityOf(element))==null);
		}
		
	}
	
	public void switchToTab(int tabindex) {
		try {
			ArrayList<String> tabs= new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs.get(tabindex));
			System.out.println("Switch to tab complete");
		}catch (Exception e) {
	         System.out.println("Switching to tab is failed ");
			
		}
		
	}
	public void clickOntabButton() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
	}
	
	
	
	
	
	
	
	public void typeText(WebElement element, String value, String elementName) {
		
			System.out.println("Enter the value ito " +elementName);
		element.sendKeys(value);
		
		
		
		
	}
	
}
